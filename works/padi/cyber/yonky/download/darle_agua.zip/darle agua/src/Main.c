#include <windows.h>
#include <stdio.h>

#include "Main.h"

static char g_szClassName[] = "MyWindowClass";
static HINSTANCE g_hInst = NULL;

#define IDC_MAIN_TEXT   1001

/*  AQUI EMPIEZA MI CODIGO...  :)

   ESTA ES LA FORMA DE COGER UN MANEJADOR AL EDIT
   hEdit = GetDlgItem(hwnd, IDC_MAIN_TEXT);

   ESTA ES LA FORMA DE PONER VALOR EN EL EDIT:
   SetWindowText(hEdit, "nanananana");
   
   ESTA ES LA FORMA DE COGER EL VALOR DEL EDIT:
   dwTextLength = GetWindowTextLength(hEdit);
   pszText = (LPSTR)GlobalAlloc(GPTR, dwTextLength + 1);
   GetWindowText(hEdit, pszText, dwTextLength + 1);
   
   */

int randn(int n)
{
   return rand()%n + 1;
}

void delchar (LPSTR text, int pos) 
{
   int i;
   LPSTR buffer;
      
   for (i=0; *(text+i) != '\0'; i++);
   buffer = (LPSTR)GlobalAlloc(GPTR, i + 1);
   
   for (i=0; i < pos; i++) 
       *(buffer+i) = *(text + i); 
   
   for (i=pos+1; *(text + i) != '\0'; i++)
       *(buffer+i-1) = *(text + i); 
   *(buffer+i-1) = '\0';
   
   for (i=0; * (buffer + i) != '\0'; i++)
      * (text + i) = * (buffer + i);
   * (text + i) = '\0';
   
   return;
}
 
void DoFileAgua (HWND hwnd) 
{   
   // HAGAS LO QUE HAGAS NO CAMBIES EL TIPO DE ESTAS VARIABLES
   HWND hEdit;
   DWORD dwTextLength;
   LPSTR pszText;
   LPSTR fullText;
   // HASTA AQUI NO CAMBIES LAS VARIABLES!!!!
   
   char cadenas[255][2048];
   int indice[255], maximo, ultimo, i, j;
   char startText[] = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><html><head><meta http-equiv=Content-Type content=\"text/html;  charset=ISO-8859-1\" /><title>Poema Aleatorio realizado con Darle Agua!!!, un programa de El Diletante Digital (http://www.eldiletante.co.nr)</title><meta http-equiv=\"content-type\" content=\"text/html; charset=ISO-8859-1\" /><meta id=\"description\" content=\"el diletante digital (eldiletante.co.nr) es un sitio cubano de net art, arte digital, hipertextos, literatura y artes plasticas. Tenemos una coleccion de revistas digitales cubanas\" /><meta id=\"keywords\" content=\"diletante digital, hipertexto, literatura, literatura digital, net art, revistas digitales cubanas, arte digital, artes plasticas, qubit, rockstalgias, disparo en red, minatura, arte cubano\" /><script language=\"javascript1.2\" src=\"scripts/aleatorio.js\" type=\"text/javascript\"></script><script language=\"javascript1.2\" src=\"scripts/tools.js\" type=\"text/javascript\"></script><link rel=\"stylesheet\" href=\"scripts/tools.css\" type=\"text/css\" />\r\n<style type=\"text/css\">p { font-family: Verdana;color: #ffffff;font-weight: normal;font-style: normal;}.vinculo {	color: #00ffff;	text-decoration: underline;	font-weight: normal;}.vinculo a:link {	color: #00ffff;	text-decoration: underline;	font-weight: normal;}.vinculo a:visited {  	color: #00ffff;	text-decoration: underline;}  /* visited link */.vinculo a:hover {  	color: #0000ff;	text-decoration: underline;	font-weight: bold;}   /* mouse over link */.vinculo a:active {	color: #00ffff;	text-decoration: underline;	font-weight: normal;}   /* selected link */</style>\r\n <script language=\"JavaScript\" type=\"text/javascript\">      <!--\r\n	  var tm;\r\nfunction hazlo () {var estribillo = new Array (";
   char endText[] = ");var anclados = new Array();var orden = new Array();var salida1=\"\";var index;estribillo = intercambiar_frases(estribillo);orden = generar_orden (estribillo.length, anclados);for (index=0; index < estribillo.length; index++) salida1 = salida1+estribillo[orden[index]];salida1 = ponerConjunciones(salida1); salida1 = poner_string_char(salida1,\"\\n\",\"<BR>\");document.body.innerHTML=\"<p>\"+salida1+\"</p>\";clearInterval(tm);tm = setInterval(\'hazlo()\', 100000);}\r\n--></script>	</head><body bgcolor=\"#000000\" onload=\"hazlo();\" onunload=\"clearInterval(tm);\">\n<noscript><font color=\"#ffffff\">Si ves esto es porque no tienes el javascript activado (lo que el Internet Explorer llama contenido activo). As&iacute; no vas a poder disfrutar de esta p&aacute;gina. Activa el javascript.</font></noscript></body></html>";
   
   hEdit = GetDlgItem(hwnd, IDC_MAIN_TEXT);
   dwTextLength = GetWindowTextLength(hEdit);
   if (!dwTextLength)
     return;
     
   pszText = (LPSTR)GlobalAlloc(GPTR, dwTextLength + 1860 + 561 + 512);
   GetWindowText(hEdit, pszText, dwTextLength + 1);
   
   // este for quita todos los \r de la cadena
   for (i=0; * (pszText + i) != '\0'; i++)
     if (* (pszText + i) == '\r') {
       delchar (pszText, i);
       i--;
     }

   // este for quita los \n del principio
   for (i=0; * (pszText + i) == '\n';)    
     delchar (pszText, i);
        
   // EN LA VARIABLE MAXIMO QUEDA EL NUMERO DE LINEAS DEL TEXTO
   for (ultimo=-2, maximo=0, i=0; *(pszText + i) != '\0'; i++) 
     if (*(pszText + i) == '\n')
       if (ultimo == i-1) {
          delchar (pszText, i);
          i--;
        }
        else {              
          maximo++;
          ultimo = i;
        }
        
   // si al final no hay un \n  se suma una linea
   if (ultimo != i-1)
     maximo++; 
   
   // despedazo el string en cadenas separadas
   for (ultimo=0, j=0, i=0; *(pszText + i) != '\0'; i++) {
     if (*(pszText + i) == '\n') {
       cadenas[ultimo][j] = '\0';
       ultimo++;
       j=0;              
     }
     else {
	   if (*(pszText + i) == '\'' || *(pszText + i) == '\"') {
		  cadenas [ultimo][j] = '\\';
          j++;
	   }
       cadenas [ultimo][j] = *(pszText + i);
       j++;
     }     
   }
   cadenas[ultimo][j] = '\0';
   
   // genero el nuevo orden de las cadenas
   for (i=0; i < maximo; i++) {
     j = randn (maximo); 
     for (ultimo=0; ultimo < i; ultimo++)
       if (indice[ultimo] == j)
          break; 
     if (ultimo < i)
       i--;
     else 
       indice[i] = j;  
   }
   
   //pone el texto del inicio
   for (j=0, ultimo=0; startText[j] != '\0'; j++, ultimo++)
        * (pszText+ultimo) = startText[j];

      
   // Copio las cadenas en el nuevo orden
   for (i=0, j=0; i < maximo; i++) {
      if (i > 0)  {
        * (pszText + ultimo) = ','; 
        ultimo++;    
        * (pszText + ultimo) = '\r'; 
        ultimo++;    
        * (pszText + ultimo) = '\n'; 
        ultimo++;    
        
      }
      * (pszText + ultimo) = '\"'; 
      ultimo++;
      * (pszText + ultimo) = ']'; 
      ultimo++;
      for (j=0; cadenas[indice[i]-1][j] != '\0'; j++, ultimo++)
        * (pszText+ultimo) = cadenas[indice[i]-1][j];
      * (pszText + ultimo) = '\\';
      ultimo++;
      * (pszText + ultimo) = 'n'; 
      ultimo++;* (pszText + ultimo) = '['; 
      ultimo++;
      * (pszText + ultimo) = '-'; 
      ultimo++;
      * (pszText + ultimo) = '\"'; 
      ultimo++;
      
   }
      
  
   //pone el texto del final
   for (j=0; endText[j] != '\0'; j++, ultimo++)
        * (pszText+ultimo) = endText[j];

   
   //cierra la cadena
   * (pszText + ultimo) = '\0'; 
   
//compruebo los valores .... solo para el debug
/*******************************************************
  for (i=0; i < maximo; i++)  
     MessageBox (NULL, cadenas[i], "About...", 0);
   
    
   char t[2];
   for (i=0; i < maximo; i++) {
     t[0] = (char) (indice[i]+48);
     t[1] = '\0';
     MessageBox (NULL, t, "About...", 0); 
   }
   
   MessageBox (NULL, pszText, "About...", 0);
*******************************************************/

   // pongo el nuevo texto en el Edit
   //fullText = strcpy (*startText,*pszText);
   SetWindowText(hEdit, pszText);
   
   return;  // chao...
}

void DoShowCode (HWND hwnd) 
{
  return;     
}

/* AQUI TERMINA MI CODIGO, NO CAMBIES MAS NADA......*/

BOOL LoadFile(HWND hEdit, LPSTR pszFileName)
{
   HANDLE hFile;
   BOOL bSuccess = FALSE;

   hFile = CreateFile(pszFileName, GENERIC_READ, FILE_SHARE_READ, NULL,
      OPEN_EXISTING, 0, 0);
   if(hFile != INVALID_HANDLE_VALUE)
   {
      DWORD dwFileSize;
      dwFileSize = GetFileSize(hFile, NULL);
      if(dwFileSize != 0xFFFFFFFF)
      {
         LPSTR pszFileText;
         pszFileText = (LPSTR)GlobalAlloc(GPTR, dwFileSize + 1);
         if(pszFileText != NULL)
         {
            DWORD dwRead;
            if(ReadFile(hFile, pszFileText, dwFileSize, &dwRead, NULL))
            {
               pszFileText[dwFileSize] = 0; // Null terminator
               if(SetWindowText(hEdit, pszFileText))
                  bSuccess = TRUE; // It worked!
            }
            GlobalFree(pszFileText);
         }
      }
      CloseHandle(hFile);
   }
   return bSuccess;
}

BOOL SaveFile(HWND hEdit, LPSTR pszFileName)
{
   HANDLE hFile;
   BOOL bSuccess = FALSE;

   hFile = CreateFile(pszFileName, GENERIC_WRITE, 0, 0,
      CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
   if(hFile != INVALID_HANDLE_VALUE)
   {
      DWORD dwTextLength;
      dwTextLength = GetWindowTextLength(hEdit);
      if(dwTextLength > 0)// No need to bother if there's no text.
      {
         LPSTR pszText;
         pszText = (LPSTR)GlobalAlloc(GPTR, dwTextLength + 1);
         if(pszText != NULL)
         {
            if(GetWindowText(hEdit, pszText, dwTextLength + 1))
            {
               DWORD dwWritten;
               if(WriteFile(hFile, pszText, dwTextLength, &dwWritten, NULL))
                  bSuccess = TRUE;
            }
            GlobalFree(pszText);
         }
      }
      CloseHandle(hFile);
   }
   return bSuccess;
}

BOOL DoFileOpenSave(HWND hwnd, BOOL bSave)
{
   OPENFILENAME ofn;
   char szFileName[MAX_PATH];

   ZeroMemory(&ofn, sizeof(ofn));
   szFileName[0] = 0;

   ofn.lStructSize = sizeof(ofn);
   ofn.hwndOwner = hwnd;
   ofn.lpstrFilter = "Web Pages (*.html)\0*.html\0*.htm\0All Files (*.*)\0*.*\0\0";
   ofn.lpstrFile = szFileName;
   ofn.nMaxFile = MAX_PATH;
   ofn.lpstrDefExt = "txt";

   if(bSave)
   {
      ofn.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY |
         OFN_OVERWRITEPROMPT;
         
      if(GetSaveFileName(&ofn))
      {
         if(!SaveFile(GetDlgItem(hwnd, IDC_MAIN_TEXT), szFileName))
         {
            MessageBox(hwnd, "Save file failed.", "Error",
               MB_OK | MB_ICONEXCLAMATION);
            return FALSE;
         }
      }
   }
   else
   {
      ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
      if(GetOpenFileName(&ofn))
      {
         if(!LoadFile(GetDlgItem(hwnd, IDC_MAIN_TEXT), szFileName))
         {
            MessageBox(hwnd, "Load of file failed.", "Error",
               MB_OK | MB_ICONEXCLAMATION);
            return FALSE;
         }
      }
   }
   return TRUE;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
   switch(Message)
   {
      case WM_CREATE:
         CreateWindow("EDIT", "",
            WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | ES_MULTILINE |
               ES_WANTRETURN,
            CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
            hwnd, (HMENU)IDC_MAIN_TEXT, g_hInst, NULL);

         SendDlgItemMessage(hwnd, IDC_MAIN_TEXT, WM_SETFONT,
            (WPARAM)GetStockObject(DEFAULT_GUI_FONT), MAKELPARAM(TRUE, 0));
      break;
      case WM_SIZE:
         if(wParam != SIZE_MINIMIZED)
            MoveWindow(GetDlgItem(hwnd, IDC_MAIN_TEXT), 0, 0, LOWORD(lParam),
               HIWORD(lParam), TRUE);
      break;
      case WM_SETFOCUS:
         SetFocus(GetDlgItem(hwnd, IDC_MAIN_TEXT));
      break;
      case WM_COMMAND:
         switch(LOWORD(wParam))
         {
            case CM_FILE_OPEN:
               DoFileOpenSave(hwnd, FALSE);
            break;
            case CM_FILE_SAVEAS:
               DoFileOpenSave(hwnd, TRUE);
            break;
            case CM_FILE_AGUA:
               DoFileAgua(hwnd);
            break;
            case CM_FILE_EXIT:
               PostMessage(hwnd, WM_CLOSE, 0, 0);
            break;
            case CM_ABOUT:
               MessageBox (NULL, "�Darle Agua! (versi�n 1.1) Un programa para hacer poemas aleatorios. Creado por Kevin Beovides Casas.\n" , "Acerca...", 0);
            break;   
         }
      break;
      case WM_CLOSE:
         DestroyWindow(hwnd);
      break;
      case WM_DESTROY:
         PostQuitMessage(0);
      break;
      default:
         return DefWindowProc(hwnd, Message, wParam, lParam);
   }
   return 0;
}



int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
   LPSTR lpCmdLine, int nCmdShow)
{
   WNDCLASSEX WndClass;
   HWND hwnd;
   MSG Msg;

   g_hInst = hInstance;

   WndClass.cbSize        = sizeof(WNDCLASSEX);
   WndClass.style         = 0;
   WndClass.lpfnWndProc   = WndProc;
   WndClass.cbClsExtra    = 0;
   WndClass.cbWndExtra    = 0;
   WndClass.hInstance     = g_hInst;
   WndClass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
   WndClass.hCursor       = LoadCursor(NULL, IDC_ARROW);
   WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
   WndClass.lpszMenuName  = "MAINMENU";
   WndClass.lpszClassName = g_szClassName;
   WndClass.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

   if(!RegisterClassEx(&WndClass))
   {
      MessageBox(0, "Window Registration Failed!", "Error!",
         MB_ICONEXCLAMATION | MB_OK | MB_SYSTEMMODAL);
      return 0;
   }

   hwnd = CreateWindowEx(
      WS_EX_CLIENTEDGE,
      g_szClassName,
      "Darle Agua",
      WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, CW_USEDEFAULT, 320, 240,
      NULL, NULL, g_hInst, NULL);

   if(hwnd == NULL)
   {
      MessageBox(0, "Window Creation Failed!", "Error!",
         MB_ICONEXCLAMATION | MB_OK | MB_SYSTEMMODAL);
      return 0;
   }

   ShowWindow(hwnd, nCmdShow);
   UpdateWindow(hwnd);

   while(GetMessage(&Msg, NULL, 0, 0))
   {
      TranslateMessage(&Msg);
      DispatchMessage(&Msg);
   }
   return Msg.wParam;
}


